﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CG2015Assignment
{
    /*

    / This class is to represent a PAUSE MENU, which can be called up during gameplay.
    / Marking scheme says to display GAME DATA, so I'm assuming this means showing each player's HEALTH and SCORE.
    / (This could also mean displaying HIGH SCORES, but that can be done in a seperate menu if needed.

    */
    class DisplayMenu
    {
    }
}
